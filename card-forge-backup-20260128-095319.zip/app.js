const chipsValue = document.getElementById("chipsValue");
const statusLine = document.getElementById("statusLine");
const cardGrid = document.getElementById("cardGrid");
const cardDetail = document.getElementById("cardDetail");
const fullDeckList = document.getElementById("fullDeckList");
const battleSlots = document.getElementById("battleSlots");
const totalCards = document.getElementById("totalCards");
const totalUpgrades = document.getElementById("totalUpgrades");
const activeSuitLabel = document.getElementById("activeSuitLabel");

const suitTabs = Array.from(document.querySelectorAll(".suit-btn"));
const suitButton = document.getElementById("suitButton");
const suitIcon = document.getElementById("suitIcon");
const powerToggle = document.getElementById("powerToggle");
const powerToggleDock = document.getElementById("powerToggleDock");
const packButtons = Array.from(document.querySelectorAll("[data-pack]"));

const ranks = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"];
const suitCycle = [
  { name: "Clubs", icon: "♣", color: "#6a00ff" },
  { name: "Hearts", icon: "♥", color: "#ff0033" },
  { name: "Diamonds", icon: "♦", color: "#00ccff" },
  { name: "Spades", icon: "♠", color: "#ff8800" }
];
const suits = [
  { name: "Hearts", key: "H", enabled: true },
  { name: "Spades", key: "S", enabled: true },
  { name: "Diamonds", key: "D", enabled: true },
  { name: "Clubs", key: "C", enabled: true }
];

let chips = 1200;
let activeSuit = "Hearts";
let selectedCardId = null;
const collection = {};
const battleDeck = [];
let cycleIndex = 0;

function basePower(rank){
  const order = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"];
  return order.indexOf(rank) + 1;
}

function getCardsForSuit(suit){
  return ranks.map(rank => ({
    id: `${suit}-${rank}`,
    rank,
    suit,
    power: basePower(rank)
  }));
}

const cardsBySuit = {
  Hearts: getCardsForSuit("Hearts"),
  Spades: getCardsForSuit("Spades"),
  Diamonds: getCardsForSuit("Diamonds"),
  Clubs: getCardsForSuit("Clubs")
};

function setStatus(message){
  if (statusLine) statusLine.textContent = message;
}

function updateChips(){
  if (chipsValue) chipsValue.textContent = chips.toString();
}

function ensureCard(id){
  if (!collection[id]) {
    collection[id] = { count: 0, level: 1 };
  }
}

function addCard(id){
  ensureCard(id);
  collection[id].count += 1;
}

function upgradeCard(id){
  if (!collection[id]) return;
  if (collection[id].count < 2) {
    setStatus("Need a duplicate to upgrade.");
    return;
  }
  collection[id].count -= 1;
  collection[id].level += 1;
  setStatus("Card upgraded.");
  renderAll();
}

function cardDisplayName(card){
  return `${card.rank} of ${card.suit}`;
}

function renderCollection(){
  if (!cardGrid) return;
  const cards = cardsBySuit[activeSuit];
  cardGrid.innerHTML = "";
  cards.forEach((card, i) => {
    const meta = collection[card.id] || { count: 0, level: 1 };
    const btn = document.createElement("button");
    btn.className = "card-item";
    btn.style.animationDelay = `${i * 0.02}s`;
    btn.innerHTML = `
      <div>
        <div class="card-rank">${card.rank}</div>
        <div class="card-suit">${card.suit}</div>
      </div>
      <div class="card-meta">
        <span>Lv ${meta.level}</span>
        <span class="card-count">x${meta.count}</span>
      </div>
    `;
    btn.addEventListener("click", () => selectCard(card.id));
    cardGrid.appendChild(btn);
  });
}

function renderCardDetail(){
  if (!cardDetail) return;
  if (!selectedCardId) {
    cardDetail.innerHTML = `
      <div class="panel-title">Card Viewer</div>
      <div class="viewer-empty">Select a card to view details.</div>
    `;
    return;
  }

  const [suitName, rank] = selectedCardId.split("-");
  const card = cardsBySuit[suitName].find(c => c.rank === rank);
  const meta = collection[selectedCardId] || { count: 0, level: 1 };
  const power = card.power + (meta.level - 1) * 2;

  cardDetail.innerHTML = `
    <div class="panel-title">Card Viewer</div>
    <div class="viewer-card">
      <div class="viewer-title">${cardDisplayName(card)}</div>
      <div class="viewer-sub">Base power ${card.power}</div>
      <div class="viewer-stats">
        <div class="viewer-stat">Level: ${meta.level}</div>
        <div class="viewer-stat">Copies: ${meta.count}</div>
        <div class="viewer-stat">Power: ${power}</div>
        <div class="viewer-stat">Suit: ${card.suit}</div>
      </div>
      <div class="viewer-actions">
        <button class="btn primary" id="btnAddToBattle">Add to Battle Deck</button>
        <button class="btn ghost" id="btnUpgradeCard">Upgrade</button>
      </div>
    </div>
  `;

  document.getElementById("btnAddToBattle")?.addEventListener("click", () => addToBattle(card.id));
  document.getElementById("btnUpgradeCard")?.addEventListener("click", () => upgradeCard(card.id));
}

function renderFullDeck(){
  if (!fullDeckList) return;
  const cards = cardsBySuit[activeSuit];
  fullDeckList.innerHTML = "";
  cards.forEach(card => {
    const meta = collection[card.id] || { count: 0, level: 1 };
    const row = document.createElement("div");
    row.className = "deck-row";
    row.innerHTML = `
      <span>${card.rank} of ${card.suit}</span>
      <span>x${meta.count} | Lv ${meta.level}</span>
    `;
    fullDeckList.appendChild(row);
  });
}

function renderBattleDeck(){
  if (!battleSlots) return;
  battleSlots.innerHTML = "";
  const maxSlots = 5;
  for (let i = 0; i < maxSlots; i += 1) {
    const slot = document.createElement("div");
    const cardId = battleDeck[i];
    slot.className = "slot" + (cardId ? " filled" : "");
    if (cardId) {
      const [suitName, rank] = cardId.split("-");
      slot.innerHTML = `
        <span>${rank} of ${suitName}</span>
        <button data-remove="${cardId}">Remove</button>
      `;
    } else {
      slot.textContent = "Empty slot";
    }
    battleSlots.appendChild(slot);
  }
  Array.from(battleSlots.querySelectorAll("button[data-remove]")).forEach(btn => {
    btn.addEventListener("click", () => removeFromBattle(btn.dataset.remove));
  });
}

function selectCard(id){
  selectedCardId = id;
  renderCardDetail();
}

function addToBattle(id){
  if (!collection[id] || collection[id].count < 1) {
    setStatus("You do not own this card yet.");
    return;
  }
  if (battleDeck.includes(id)) {
    setStatus("That card is already in the battle deck.");
    return;
  }
  if (battleDeck.length >= 5) {
    setStatus("Battle deck is full.");
    return;
  }
  battleDeck.push(id);
  setStatus("Card added to battle deck.");
  renderBattleDeck();
}

function removeFromBattle(id){
  const index = battleDeck.indexOf(id);
  if (index >= 0) battleDeck.splice(index, 1);
  renderBattleDeck();
}

function clearBattleDeck(){
  battleDeck.length = 0;
  renderBattleDeck();
  setStatus("Battle deck cleared.");
}

function updateProfileStats(){
  if (!totalCards || !totalUpgrades) return;
  let total = 0;
  let upgrades = 0;
  Object.values(collection).forEach(meta => {
    total += meta.count;
    upgrades += meta.level - 1;
  });
  if (totalCards) totalCards.textContent = total.toString();
  if (totalUpgrades) totalUpgrades.textContent = upgrades.toString();
}

function buyPack(size, cost){
  if (chips < cost) {
    setStatus("Not enough chips.");
    return;
  }
  if (!suits.find(s => s.name === activeSuit && s.enabled)) {
    setStatus("This suit is locked.");
    return;
  }
  chips -= cost;
  updateChips();
  const cards = cardsBySuit[activeSuit];
  for (let i = 0; i < size; i += 1) {
    const card = cards[Math.floor(Math.random() * cards.length)];
    addCard(card.id);
  }
  setStatus(`You opened a ${size}-card pack.`);
  renderAll();
}

function setActiveSuit(suitName){
  const suit = suits.find(s => s.name === suitName);
  if (!suit || !suit.enabled) {
    setStatus("Suit locked for now.");
    return;
  }
  activeSuit = suitName;
  selectedCardId = null;
  suitTabs.forEach(tab => tab.classList.toggle("active", tab.dataset.suit === suitName));
  if (activeSuitLabel) activeSuitLabel.textContent = suitName;
  if (document.body) {
    document.body.dataset.suit = suitName.toLowerCase();
  }
  try {
    window.localStorage.setItem("activeSuit", suitName);
  } catch {}
  syncSuitButton();
  renderAll();
}

function seedStarterCards(){
  const starter = ["A","7","K"];
  starter.forEach(rank => addCard(`Hearts-${rank}`));
}

function renderAll(){
  renderCollection();
  renderCardDetail();
  renderFullDeck();
  renderBattleDeck();
  updateProfileStats();
}

function syncSuitButton(){
  if (!suitButton || !suitIcon) return;
  const data = suitCycle.find(item => item.name === activeSuit);
  if (!data) return;
  suitButton.style.setProperty("--c", data.color);
  suitIcon.textContent = data.icon;
  cycleIndex = suitCycle.indexOf(data);
}

suitTabs.forEach(tab => {
  tab.addEventListener("click", () => setActiveSuit(tab.dataset.suit));
});

if (suitButton) {
  suitButton.addEventListener("click", () => {
    cycleIndex = (cycleIndex + 1) % suitCycle.length;
    setActiveSuit(suitCycle[cycleIndex].name);
    suitButton.classList.remove("swap");
    void suitButton.offsetWidth;
    suitButton.classList.add("swap");
    window.setTimeout(() => suitButton.classList.remove("swap"), 520);
    suitButton.classList.remove("anim");
    void suitButton.offsetWidth;
    suitButton.classList.add("anim");
    window.setTimeout(() => suitButton.classList.remove("anim"), 800);
  });
}

packButtons.forEach(btn => {
  btn.addEventListener("click", () => {
    const size = Number(btn.dataset.pack || 0);
    const cost = Number(btn.dataset.cost || 0);
    buyPack(size, cost);
  });
});

document.getElementById("btnClearBattle")?.addEventListener("click", clearBattleDeck);
document.getElementById("btnAddChips")?.addEventListener("click", () => {
  chips += 500;
  updateChips();
  setStatus("Added 500 chips.");
});

seedStarterCards();
updateChips();
try {
  const storedSuit = window.localStorage.getItem("activeSuit");
  if (storedSuit && suits.find(s => s.name === storedSuit)) {
    activeSuit = storedSuit;
  }
} catch {}
if (document.body) document.body.dataset.suit = activeSuit.toLowerCase();
syncSuitButton();
renderAll();


function setPowerState(isOn){
  if (!document.body) return;
  document.body.dataset.power = isOn ? "on" : "off";
  try {
    window.localStorage.setItem("powerState", isOn ? "on" : "off");
  } catch {}
  syncPowerToggles(isOn);
}

function syncPowerToggles(isOn){
  if (powerToggle) powerToggle.checked = isOn;
  if (powerToggleDock) powerToggleDock.checked = isOn;
}

if (powerToggle) {
  powerToggle.addEventListener("change", () => setPowerState(powerToggle.checked));
}
if (powerToggleDock) {
  powerToggleDock.addEventListener("change", () => setPowerState(powerToggleDock.checked));
}

try {
  const storedPower = window.localStorage.getItem("powerState");
  if (storedPower) {
    const on = storedPower === "on";
    syncPowerToggles(on);
    setPowerState(on);
  } else {
    setPowerState(true);
    syncPowerToggles(true);
  }
} catch {
  setPowerState(true);
  syncPowerToggles(true);
}
